import Link from "next/link";
import NavStyles from "./styles/NavStyles";
import User from "./User";
import Signout from "./Signout";
import MyCart from "./MyCart";

const Nav = () => (
    <User>
        {({ data }) => {
            const me = data ? data.me : null;
            return (
                <NavStyles>
                    <Link href="/items">
                        <a>Shop</a>
                    </Link>
                    {me && (
                        <React.Fragment>
                            <Link href="/sell">
                                <a>Sell</a>
                            </Link>
                            <Link href="/orders">
                                <a>Orders</a>
                            </Link>
                            <Link href="/me">
                                <a>Account</a>
                            </Link>
                            <Signout />
                            <MyCart />
                            {/*

                            <Mutation mutation={TOGGLE_CART_MUTATION}>
                                {toggleCart => (
                                    <button onClick={toggleCart}>
                                        My Cart
                                        <CartCount
                                            count={me.cart.reduce(
                                                (tally, cartItem) =>
                                                    tally + cartItem.quantity,
                                                0
                                            )}
                                        ></CartCount>
                                    </button>
                                )}
                            </Mutation>
                            */}
                        </React.Fragment>
                    )}
                    {!me && (
                        <React.Fragment>
                            <Link href="/signup">
                                <a>Sign In / Register</a>
                            </Link>
                            <MyCart />
                        </React.Fragment>
                    )}
                </NavStyles>
            );
        }}
    </User>
);
export default Nav;
